library(testthat)
library(stanfactory)
test_check("stanfactory")
